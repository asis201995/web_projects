var id = "no";
var data = [];
var members = [];

var countries = [
    {  name:"----Choose a option----",
    id:"0",
    colorCode:"white"
   },
    {
    name:"India",
    id:"1",
    colorCode:"blue",
    tbColorCode:"white"
},{
    name:"Australia",
    id:"2",
    colorCode:"yellow",
    tbColorCode:"white"
},
{
    name:"Pakistan",
    id:"2",
    colorCode:"green",
    tbColorCode:"white"
},
    {
        name:"Srilanka",
        id:"2",
        colorCode:"navy",
        tbColorCode:"white"
    }
]

window.addEventListener('DOMContentLoaded',(event)=>{
  
    showTable();
    CreateCountryDropdownOptions();
});


function CreateCountryDropdownOptions(){
    var countryOptions = "";
    countries.forEach(x=>{
      //  debugger;
countryOptions+=`<option value=${x.name} id="${x.id}" data-tbColorCode=${x.tbColorCode} data-colorcode=${x.colorCode}>${x.name}</option>`
    });
    document.getElementById('country').innerHTML = countryOptions;
}

function show() {
    document.getElementById("popup").style.display = "block";
}

function submitClick() {
    var x = document.getElementById("name").value;
    var y = document.getElementById("country").value;
    var m = document.getElementById("member").value;
    var tdata = {
        Tname: "",
        Country: "",
        Tmembers: ""
    };
    if (x==""&&y==""&&m=="") 
    {
        document.getElementById("message").innerHTML="enter all field first";
    } else {document.getElementById("message").innerHTML = "";
        if (id == "no") {
            tdata.Tname = x;
            tdata.Country = y;
            tdata.Tmembers = members;
            if (members.length < 11) { add(); }
            else { document.getElementById("message").innerHTML = "maximum member added"; } 
            data.push(tdata);
            var mystr = JSON.stringify(data);
            localStorage.setItem("league", mystr);
            reset();
            document.getElementById("popup").style.display = "none";
        }
        else {
            let arr = getData();
            tdata = {
                Tname: x,
                Country: y,
                Tmembers: members
            };
            if (members.length < 11) { members.push(m); }
            else { document.getElementById("message").innerHTML = "maximum member added"; }
            arr[id] = tdata;
            setData(arr);
            document.getElementById("message").innerHTML = "";
            reset();
            document.getElementById("popup").style.display = "none";
        }
    }
    showTable();
    members = [];
}

function reset() {
    document.getElementById("name").value = "";
    document.getElementById("country").value = "";
    document.getElementById("member").value = "";
}

function getData() {
    let arr = JSON.parse(localStorage.getItem('league'));
    return arr;
}

function setData(data) {
    localStorage.setItem('league', JSON.stringify(data));
}

function showTable() {
    debugger;
    var arr = getData();
    if (arr != null) {
        let a = "";
        let serno = 1;
        for (var k in arr) {
            a = a + `<tr><td>${serno}</td><td>${arr[k].Tname}</td><td>${arr[k].Country}</td>
       <td><a onclick="ShowClick(${k})"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
       <td><button onclick="EditClick(${k})" id="btn4">edit</button></td>
        <td><button onclick="DeleteClick(${k})" id="btn5">delete</button></td></tr>`;
            serno++;
        }
        document.getElementById("tb").innerHTML = a;
    }
    document.body.style.background = "white";
    document.getElementById("tbl1").style.background = "whit";
    document.getElementById("popup").style.background = "white";
    document.getElementById("tbl2").style.background = "white";
    document.getElementById("searchbar").style.background = "white";
}

function EditClick(rid) {
    document.getElementById("poptable").style.display = "none";
    id = rid;
    show();
    let arr = getData();
    document.getElementById("name").value = arr[rid].Tname;
    document.getElementById("country").value = arr[rid].Country;
    document.getElementById("member").value = arr[rid].Tmembers;
}

function DeleteClick(rid) {
    document.getElementById("poptable").style.display = "none";
    let arr = getData();
    arr.splice(rid, 1);
    setData(arr);
    showTable();
}

function showtab() {
    document.getElementById("poptable").style.display = "block";
}

function ShowClick(rid) {
    let arr = getData();
    if (arr != null) {
        let a = "";
        let serno = 1;
        a = a + `<tr><td>${serno}</td><td>${arr[rid].Tname}</td><td>${arr[rid].Country}</td>
           <td>${arr[rid].Tmembers}</td><td><button onclick="CancelTab()">Cancel</button></td></tr>`;
        serno++;
        document.getElementById("tb1").innerHTML = a;
        showtab();
    }
}

function add() {
    var m = document.getElementById("member").value;
    if (members.length == 0 || members.length < 11) { members.push(m); }
    else { document.getElementById("message").innerHTML = "maximum member added"; }
    document.getElementById("member").value = "";
}

function SearchClick() {
    let arr = getData();
    var s = document.getElementById("search").value;
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].Tname == s || arr[i].Country == s) {
            let a = "";
            let serno = 1;
            a = a + `<tr><td>${serno}</td><td>${arr[i].Tname}</td><td>${arr[i].Country}</td>
              <td>${arr[i].Tmembers}</td><td><button onclick="CancelTab()">Cancel</button></td></tr>`;
            serno++;
            document.getElementById("tb1").innerHTML = a;
            showtab();
            document.getElementById("search").value = "";
        }
    }
}

function CancelPop() {document.getElementById("message").innerHTML = "";
    document.getElementById("popup").style.display = "none";
}

function CancelTab() {
    document.getElementById("poptable").style.display = "none";
}

function ColorChange(event) {
        document.body.style.background = event.options[event.selectedIndex].dataset.colorcode;
        document.getElementById("tbl1").style.background = event.options[event.selectedIndex].dataset.tbColorCode;
}
