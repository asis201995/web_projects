var patients = [];
var patient = {
    name: "",
    phone: [],
    email: "",
    gender: "",
    alergies: [],
    address: ""
};
var ph = [];
var id = "no";
var k=0;
window.addEventListener('DOMContentLoaded', (event) => {
    showTable();
});

function ValidateName() {
    document.getElementById("message").innerHTML = "";
    var uname = document.getElementById("name").value;
    if (uname.length < 4) {
        document.getElementById("msg1").innerHTML = "Name too short please enter atleast 4 letter name";
    }
    else if (isNaN(uname)) {
        var result = uname.charAt(0).toUpperCase() + uname.slice(1);
        document.getElementById("name").value = result;
        document.getElementById("msg1").innerHTML = "";
    }
    else {
        document.getElementById("msg1").innerHTML = "Name cant be number or space";
    }
}

function ValidatePhone() {
    document.getElementById("message").innerHTML = "";
    var isValid=false;
    var phn = [];
    var regphone = /^\d{10}$/;
    document.querySelectorAll('.phone').forEach(function (item) {
        phn.push(item.value);
    });
    for(var i of phn){
    if (regphone.test(i)) {
        document.getElementById("msg2").innerHTML = "";
    } else {
        document.getElementById("msg2").innerHTML = "Invalid phone number";
        isValid=true;
    }
}
return isValid;
}

function ValidateEmail() {
    document.getElementById("message").innerHTML = "";
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.getElementById("email").value)) {
        document.getElementById("msg3").innerHTML = "";
        return (true)
    }
    document.getElementById("msg3").innerHTML = " Invalid email address! please enter a valid email address like this(abc@xyz.com/abc.xyz.in) ";
    return (false)
}

function getData() {
    let arr = JSON.parse(localStorage.getItem('patient'));
    return arr;
}

function setData(data) {
    localStorage.setItem('patient', JSON.stringify(data));
}

function submitClick() {
    debugger;
    var a = document.getElementById("name").value;
    var b = "";
    document.querySelectorAll('.phone').forEach(function (item) {
        b = item.value;
    });
    var c = document.getElementById("email").value;
    var err=true;
    var checkBoxes = document.querySelectorAll('input[type="checkbox"]'); 
    checkBoxes.forEach(item => {
        if (item.checked) {
            err = false;
        }
    });
    if (a == "" && b == "" && c == ""&& err==true) {
        document.getElementById("msg1").innerHTML ="Name cant be empty";
        document.getElementById("msg3").innerHTML ="Email cant be empty";
        document.getElementById("msg2").innerHTML ="Phone number cant be empty";
        document.getElementById("msg5").innerHTML ="Alergies cant be empty";
    }else if(a==""){
        document.getElementById("msg1").innerHTML ="Name cant be empty";
    }else if(b==""){
        document.getElementById("msg2").innerHTML ="phone cant be empty";
    }else if(c==""){
        document.getElementById("msg3").innerHTML ="Email cant be empty";
    }else if(err==true){
        document.getElementById("msg5").innerHTML ="Alergies cant be empty";
    }
    else {
        ValidateName();
        if(ValidatePhone())
        {  
             document.getElementById("msg2").innerHTML ="Phone number changed!!!"; 
              return;
        }
        ValidateEmail();
        if (id == "no") {
            var arr = getData();
            if (arr == null) {
                document.getElementById("message").innerHTML = "";
                let checkboxes = [];
                document.querySelectorAll('.phone').forEach(function (item) {
                    ph.push(item.value);
                });
                document.querySelectorAll('input[type="checkbox"]:checked').forEach(function (item) {
                    checkboxes.push(item.value);
                });
                patient = {
                    name: document.getElementById("name").value,
                    phone: ph,
                    email: document.getElementById("email").value,
                    gender: document.getElementById("gender").value,
                    alergies: checkboxes,
                    address: document.getElementById("address").value
                };

                patients.push(patient);
                var mystr = JSON.stringify(patients);
                localStorage.setItem("patient", mystr);
                ph = [];
                showTable();
                reset();
            } else {
                document.getElementById("message").innerHTML = "";
                let checkboxes = [];
                document.querySelectorAll('.phone').forEach(function (item) {
                    ph.push(item.value);
                });
                document.querySelectorAll('input[type="checkbox"]:checked').forEach(function (item) {
                    checkboxes.push(item.value);
                });
                patient = {
                    name: document.getElementById("name").value,
                    phone: ph,
                    email: document.getElementById("email").value,
                    gender: document.getElementById("gender").value,
                    alergies: checkboxes,
                    address: document.getElementById("address").value
                };

                arr.push(patient);
                var mystr = JSON.stringify(arr);
                localStorage.setItem("patient", mystr);
                ph = [];
                showTable();
                document.getElementById("msg1").innerHTML ="";
                document.getElementById("msg3").innerHTML ="";
                document.getElementById("msg2").innerHTML ="";
                document.getElementById("msg5").innerHTML ="";
                reset();
            }
        }
        else {
            let arr = getData();
            arr[id].name = document.getElementById("name").value;
            arr[id].phone = ph;
            arr[id].email = document.getElementById("email").value;
            arr[id].gender = document.getElementById("gender").value;
            arr[id].address = document.getElementById("address").value;
            let checkboxes = [];
            document.querySelectorAll('.phone').forEach(function (item) {
                ph.push(item.value);
            });
            document.querySelectorAll('input[type="checkbox"]:checked').forEach(function (item) {
                checkboxes.push(item.value);
            });
            arr[id].alergies = checkboxes;
            setData(arr);
            ph = [];
            showTable();
            document.getElementById("message").innerHTML = "";
            reset();
        }
    }
    document.getElementById("inp").innerHTML = "";
}

function reset() {
    document.getElementById("name").value = "";
    document.querySelectorAll('.phone').forEach(function (item) {
        item.value = "";
    });
    document.getElementById("email").value = "";
    document.getElementById("gender").value = "";
    document.getElementById("address").value = "";
    var inputs = document.querySelectorAll('.checkbox');
    for (var i = 0; i < inputs.length; i++) {
        inputs[i].checked = false;
    }
    document.location.reload(true);
  }

function showTable() {
    debugger;
    var arr = getData();
    if (arr != null) {
        let html = "";
        for (var k in arr) {
            html = html + `<tr><td>${arr[k].name}</td><td>${arr[k].phone}</td>
            <td>${arr[k].email}</td><td>${arr[k].alergies}</td>
       <td><a onclick="EditClick(${k})"><i class="far fa-edit"></i></a></td>
        <td><a onclick="DeleteClick(${k})"><i class="far fa-trash-alt"></i></a></td></tr>`;
        }
        document.getElementById("tb").innerHTML = html;
    }
}

function EditClick(rid) {
    debugger;
    id = rid;
    let arr = getData();
    document.getElementById("inp").innerHTML="";
    document.querySelectorAll('input[type="checkbox"]').forEach(function(item)
    {
       item.checked=false;
    });
    document.querySelectorAll(".phone").forEach(function(item){
        item.value="";
    });
    document.getElementById("name").value = arr[rid].name;
    var phnm=arr[rid].phone;
    document.getElementById("phone").value=phnm[0];
    for(var j=1;j<phnm.length;j++){
    var x = document.createElement("INPUT");
    var y= document.createElement("button");
    var z=document.createElement("span");
    y.innerHTML=`<i class="fas fa-times-circle"></i>`;
    x.setAttribute("type", "text",);
    x.setAttribute("class", "phone");
    x.setAttribute("onblur", "ValidatePhone()");
    x.setAttribute("maxlength", "10");
    y.setAttribute("id",`${k}`);
    y.setAttribute("onclick","cancelInput(this.id)");
    z.setAttribute("id",`${k}`);
    z.appendChild(x);
    z.appendChild(y);
    document.getElementById("inp").appendChild(z);
     x.value=phnm[j];
     k++;
    }
    document.getElementById("email").value = arr[rid].email;
    document.getElementById("gender").value = arr[rid].gender;
    document.getElementById("address").value = arr[rid].address;
    var inputs = arr[rid].alergies;
    for (var i of inputs) {
        document.querySelector(`input[type="checkbox"][value="${i}"]`).checked = true;
    }

}

function DeleteClick(rid) {
    let arr = getData();
    arr.splice(rid, 1);
    setData(arr);
    showTable();
}


function AddNumber() {
    debugger;
    var m="";
    document.querySelectorAll('.phone').forEach(function (item) {
        m=item.value;
    });
    if(m==""){
        document.getElementById("msg2").innerHTML="please enter the phone number field before entering to new field";
    }else{
    var x = document.createElement("INPUT");
    var y= document.createElement("button");
    var z=document.createElement("span");
    y.innerHTML=`<i class="fas fa-times-circle"></i>`;
    x.setAttribute("type", "text",);
    x.setAttribute("class", "phone");
    x.setAttribute("onblur", "ValidatePhone()");
    x.setAttribute("maxlength", "10");
    y.setAttribute("id",`${k}`);
    y.setAttribute("onclick","cancelInput(this.id)");
    z.setAttribute("id",`${k}`);
    z.appendChild(x);
    z.appendChild(y);
    document.getElementById("inp").appendChild(z);
    k++;
 }
}

function resetClick(){
    document.getElementById("inp").innerHTML = "";
    document.getElementById("msg1").innerHTML ="";
    document.getElementById("msg3").innerHTML ="";
    document.getElementById("msg2").innerHTML ="";
    document.getElementById("msg5").innerHTML ="";
}

function cancelInput(clicked_id){
    debugger;
    var list = document.getElementById("inp");
    let d_nested = document.getElementById(`${clicked_id}`);
    list.removeChild(d_nested);;
}
