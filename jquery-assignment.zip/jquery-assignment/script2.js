var subject=[];
var Data = [];
var student = {
    name: "",
    email:"",
    country: "",
    state: "",
    subject:"",
    mark:""
};
var id=-1;
$(document).ready(function() {
    CreateCountryDropdownOptions();
    CreateSubjectDropdownOptions();
    showTable();
    $('#name').on('blur',function(){
     validateName();
    });
    $('input[type=number]').on('blur',function(){
      validateMark();
    });
    $('input[type=email]').on('blur',function(){
     validateEmail();
    });

    $("#country").on("change",function(){
        CountryChange() ;
    })

    $(".edit").on("click",function(){
        debugger;
        var rid=$(this).attr('id');
        EditClick(rid);
    })

    
    $(".delete").on("click",function(){
        debugger;
        var rid=$(this).attr('id');
        DeleteClick(rid);
    })

    $("#sub").on("blur",function(){
        var arry=JSON.parse(localStorage.getItem('Subjects'));
        var sub=$("#sub").val();
        var temp=false;
        if(sub==""){
            $("#msg1").text(" Subject can not be empty please enter a subject");
            return;
        }else{
            if(arry==null){
                subject.push(sub);
                localStorage.setItem('Subjects', JSON.stringify(subject));
            }else{
                arry.forEach(x=>{
                    if(sub==x)
                    {
                        temp= true;
                    }
               });
                if(temp){
                    $("#msg1").text(" Subject alredy exist");
                    return;
                }else{
                    $("#msg1").text("");
                    arry.push(sub);
                    localStorage.setItem('Subjects', JSON.stringify(arry));
                }
            }
        }
        CreateSubjectDropdownOptions();
        $("#sub").val("");
    })
    $('button').on("click",function(){
        SaveData();
    });
})

function CreateSubjectDropdownOptions(){
    $("#subject").html("");
    var arry=JSON.parse(localStorage.getItem('Subjects'));
    if(arry==null){
        return;
    }else{
        arry.forEach(x=>{
            $('#subject').append($('<option>').val(x).text(x));
           });
    }
  
} 

function CreateCountryDropdownOptions(){
    $("#country").html("");
    var arry=JSON.parse(localStorage.getItem('Countries'));
    if(arry==null){
        return;
    }else{
        arry.forEach(x=>{
            $('#country').append($('<option>').val(x.name).text(x.name));
           });
    }
  
} 

function CountryChange() {
    debugger;
    var c1 = $("#country").val();
    $("#state").html("");
    var arr = JSON.parse(localStorage.getItem('Countries'));
    arr.forEach(x => {
        if (c1 == x.name) {
            var arry = x.state;
            arry.forEach(x=>{
                $('#state').append($('<option>').val(x).text(x));
               });
        }
    });
}

function validateEmail(){
    debugger;
      var email=$("#email").val();
      if(email==""){
        $("#msg3").text("please enter a email");
        return true;
      }else{
        if((/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/).test(email)){
            $("#msg3").text("");
          }else{
            $("#msg3").text("Invalid Email");
          }
      }
  }

  function validateName(){
    var name=$("#name").val();
    debugger;
    if(name==""){
        $("#msg1").text("name cant be empty");
        return true;
    }else{
        if((/^[a-zA-Z]+$/).test(name)){
            $("#msg1").text("");
        }else{
          $("#msg1").text("Invalid Name");
        }
    }
}

 function validateMark(){
    debugger;
      var mark=$("#mark").val();
     if(mark==""){
        $("#msg7").text("please enter mark");
        return true;
     }else{
         if(mark>100){
            $("#msg7").text("invalid mark");
         }else{
            $("#msg7").text("");
         }
     
        }
    }


function getdata() {
    let arr = JSON.parse(localStorage.getItem('Data'));
    return arr;
}

function setData(data) {
    localStorage.setItem('Data', JSON.stringify(data));
}

function SaveData() {
    debugger;
    var arr = getdata();
    if (Validateform()) {
        return;
    } else {
        if (id ==-1) {
            if (arr == null) {
                student = {
                    name: $("#name").val(),
                    email:$("#email").val(),
                    country: $("#country").val(),
                    state: $("#state").val(),
                    subject:$("#subject").val(),
                    mark:$("#mark").val()
                };
                Data.push(student);
                setData(Data)
                showTable();
                reset();
            } else {
                student = {
                    name: $("#name").val(),
                    email:$("#email").val(),
                    country: $("#country").val(),
                    state: $("#state").val(),
                    subject:$("#subject").val(),
                    mark:$("#mark").val()
                };
                arr.push(student);
                setData(arr)
                showTable();
                reset();
            }
        }
        else {
            let arr = getdata();
            arr[id].name = $("#name").val();
            arr[id].country =  $("#country").val();
            arr[id].state =  $("#state").val();
            arr[id].email =  $("#email").val();
            arr[id].subject=  $("#subject").val();
            arr[id].mark =  $("#mark").val();
            setData(arr);
            showTable();
            reset();
            id=-1;
        }
        window.location.reload();
    }
}

function Validateform(){
   var state= $("#state").val();
 validateEmail();
 validateName();
 validateMark();
 if(validateMark()||validateName()||validateName()||state==""){
     return true;
 }else{
     return false;
 }
}

function reset() {
    debugger;
    $("#name").val("");
    $("#email").val("");
    $("#mark").val("");
    $("#state").val("");
    CreateSubjectDropdownOptions();
    CreateCountryDropdownOptions()
}

function showTable() {
    debugger;
    $('#tb').html("");
    var arr = getdata();
    if (arr != null) {
        for (var k in arr) {
        $('#tb').append("<tr><td>" +`${arr[k].name}` + "</td><td>" + `${arr[k].email}`+ "</td><td>" + `${arr[k].country}`+ "</td><td>" + `${arr[k].state}`+ "</td><td>" +`${arr[k].subject}`+ "</td><td>" +`${arr[k].mark}`+ "</td><td>" + `<a id="${k}" class="edit"><i class="far fa-edit"></i></a>`+ "</td><td>" + `<a id="${k}" class="delete"><i class="far fa-trash-alt"></i></a>`+ "</td></tr>");
        }
    }
}

function EditClick(rid) {
    debugger;
    id = rid;
    let arr = getdata();
    $("#name").val(`${arr[rid].name}`);
    $("#email").val(`${arr[rid].email}`);
    $("#country").val(`${arr[rid].country}`);
    CountryChange();
    $("#state").val(`${arr[rid].state}`);
    $("#subject").val(`${arr[rid].subject}`);
    $("#mark").val(`${arr[rid].mark}`);
}

function DeleteClick(rid) {
    let arr = getdata();
    arr.splice(rid, 1);
    setData(arr);
    reset();
    showTable();
    window.location.reload();
}
