var Countries=[];

$(document).ready(function() {
    CreateCountryDropdownOptions();
    $('#cname').on('blur',function(){
        validateCountry();
    });

    $('#state').on('blur',function(){
        validateSate();
    });

    $('#btn1').on('click',function(e) {
        debugger;
        var countryName=$("#cname").val();
        var arry= getValue();
        if(arry==null){
            var counntry={
                 name:"",
                 state:[]
               };
               counntry.name=countryName;
               Countries.push(counntry);
               createItem(Countries);
            }else{
                var counntry={
                    name:"",
                     state:[]
                   };
                   counntry.name=countryName;
                   arry.push(counntry);
                   createItem(arry);
            }
            $("#cname").val('');
            $("#msg1").text("");
             CreateCountryDropdownOptions();
             e.preventDefault();
         });
         
    $('#btn2').on('click',function(e) {
        saveState();
        e.preventDefault();
    });
})

function validateCountry(){
    debugger;
    var name=$("#cname").val();
    if(name==""){
        $("#msg1").text("Country Name can not be empty");
    }
   else if((/^[a-zA-Z]+$/).test(name)){
    var arry= getValue();
    var temp=false;
    arry.forEach(x=>{
        if(name==x.name)
        {
            temp= true;
        }
   });
    if(temp){
        $("#msg1").text(" Country Name alredy exist");
        return;
    }else{
        $("#msg1").text("");
    }
}
    else{
      $("#msg1").text("Invalid Country Name");
    }
}

function validateState(){ 
    debugger;
    var sname=$("#state").val();
    if(sname==""){
        $("#msg2").text("State Name can not be empty");
    }
   else if((/^[a-zA-Z]+$/).test(sname)){
    var arry= getValue();
    var temp=false;
   arry.forEach(x=>{
    (x.state).forEach(element => {
        if(element==sname){
           temp=true;
        }
    });
});
    if(temp){
        $("#msg2").text("Sate Name alredy exist");
        return;
    }else{
        $("#msg2").text("");
    }
}
    else{
      $("#msg2").text("Invalid State Name");
    }
}

function saveState(){
    validateState();
    var arry=getValue();
    var u=$("#cnt").val();
    var c=$("#state").val();
    if(c==""){
        return;
    }else{
    arry.forEach(x=>{
                if(u==x.name)
                {
                x.state.push(c); 
                createItem(arry);
                } 
        }); }
        $("#state").val("");
 }

function CreateCountryDropdownOptions(){
    document.getElementById("cnt").innerHTML="";
    var arry=getValue();
    if(arry==null){
        return;
    }else{
        arry.forEach(x=>{
            $('#cnt').append($('<option>').val(x.name).text(x.name));
           });
    }
  
} 

function createItem(data) {
    localStorage.setItem('Countries', JSON.stringify(data));
} 


function getValue() {
	let arr = JSON.parse(localStorage.getItem('Countries'));
    return arr;  
}
//console.log(getValue());